package it.mws2018039.testsharedpreference;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    LinearLayout layout;
    TextView tv;
    TextView tv2;
    private static final String PREF_NOME = "NOME";
    private static final String PREF_FILE = "PROVA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        Button bottone = new Button(this);
        layout = new LinearLayout(this);
        layout.addView(bottone);
        tv = new TextView(this);
        layout.addView(tv);
        setContentView(layout);
        */
        Button bottone = findViewById(R.id.main_btn);
        tv = findViewById(R.id.main_tv);
        tv2 = findViewById(R.id.main_test_tv);


        Button btn2 = new Button(this);
        btn2.setText("nuovo bottone");
        LinearLayout ll = findViewById(R.id.main_ly);
        ll.addView(btn2);

        SharedPreferences settings = getSharedPreferences(MainActivity.PREF_FILE, 0);
        String nome = settings.getString(MainActivity.PREF_NOME, "Nessun valore inserito");
        tv.setText("risultato:"+ nome);

        bottone.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                SharedPreferences settings = getSharedPreferences(MainActivity.PREF_FILE, 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString(MainActivity.PREF_NOME,"Lele" );

                editor.commit();
                String nome = settings.getString(MainActivity.PREF_NOME, "Nessun valore inserito");
                tv.setText("risultato:"+ nome);
                tv2.setVisibility(View.VISIBLE);
            }
        });

    }
}
